print ("Python has 10 type of booleans", True, " and ", False)
print ("They are normally the result of comparisons")

num = 8
if num < 10:
    print (num, " is less than 10")
else:
    print (num, " is not less than 10")


print ("What we just saw are conditional statements.")
print ("It's ok if you do not understand them, we will look into them in greater details very soon.")
