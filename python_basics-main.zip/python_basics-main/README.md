# python_basics
This repo has simple programs for beginners starting their programming journey in python
It has a weight converter program which helps understand simple concepts of taking input from the user, need for typecasting, etc.
